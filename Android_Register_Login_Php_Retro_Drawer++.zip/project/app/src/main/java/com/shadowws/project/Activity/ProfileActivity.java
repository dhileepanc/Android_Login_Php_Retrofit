package com.shadowws.project.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.shadowws.project.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {
    private ImageView mDrawerHeaderImage;
    private TextView mNameText;
    private TextView mEmailText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        // Change top color to white
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        // Remove title
        getSupportActionBar().hide();

        // Find views
        mDrawerHeaderImage = findViewById(R.id.drawer_header_image);
        mNameText = findViewById(R.id.drawer_header_text);
mEmailText = findViewById(R.id.profile_email);

        // Retrieve intent extras
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String email=intent.getStringExtra("email");
        String profilePicString = intent.getStringExtra("profile_pic");
        Bitmap profilePicBitmap = decodeProfilePic(profilePicString);


        // Set name and email text in TextViews
        mNameText.setText(name);
        mEmailText.setText(email);
        mDrawerHeaderImage.setImageBitmap(profilePicBitmap);

    }
    private Bitmap decodeProfilePic(String encodedPic) {
        if (encodedPic == null) {
            return null;
        }
        byte[] decodedBytes = Base64.decode(encodedPic, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}