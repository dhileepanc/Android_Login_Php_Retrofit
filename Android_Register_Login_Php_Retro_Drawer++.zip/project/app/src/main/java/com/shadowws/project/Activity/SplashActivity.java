package com.shadowws.project.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.shadowws.project.R;

public class SplashActivity extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 3000; // 3 seconds

    private ImageView topImage, bottomImage;
    private TextView appName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Change top color to white
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        // Remove title
        getSupportActionBar().hide();

        topImage = findViewById(R.id.top_image);
        bottomImage = findViewById(R.id.bottom_image);
        appName = findViewById(R.id.app_name);

        // Animation for top and bottom images
        Animation topAnim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        topImage.setAnimation(topAnim);

        Animation bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);
        bottomImage.setAnimation(bottomAnim);

        // Animation for app name
       /* Animation appNameAnim = AnimationUtils.loadAnimation(this, R.anim.app_name_animation);
        appName.setAnimation(appNameAnim);*/

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                Intent i = new Intent(SplashActivity.this,MainActivity.class);
                startActivity(i);

                finish();
            }
        }, SPLASH_TIME_OUT);
    }
}