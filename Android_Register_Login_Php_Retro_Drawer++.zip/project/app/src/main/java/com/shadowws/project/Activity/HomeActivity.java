package com.shadowws.project.Activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.shadowws.project.R;

import java.io.IOException;

public class HomeActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private DrawerLayout mDrawerLayout;
    private ImageView mDrawerHeaderImage;
    private TextView mDrawerHeaderText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Change top color to white
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        // Remove title
        getSupportActionBar().hide();

        // Set up navigation drawer
        mDrawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.navigation_view);

        // Set up drawer header
        View headerView = navigationView.getHeaderView(0);
        mDrawerHeaderImage = headerView.findViewById(R.id.drawer_header_image);
        mDrawerHeaderText = headerView.findViewById(R.id.drawer_header_text);




        // Get name from intent and set it in the drawer header
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String email=intent.getStringExtra("email");
        String profilePicString = intent.getStringExtra("profile_pic");
        Bitmap profilePicBitmap = decodeProfilePic(profilePicString);

        mDrawerHeaderImage.setImageBitmap(profilePicBitmap);

        mDrawerHeaderText.setText(name);



        // Set up navigation item click listener
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                switch (itemId) {
                    case R.id.nav_home:
                        // Redirect to HomeActivity
                        Intent homeIntent = new Intent(HomeActivity.this, HomeActivity.class);
                        homeIntent.putExtra("name", name);
                        homeIntent.putExtra("email", email);
                        homeIntent.putExtra("profile_pic", profilePicString);
                        startActivity(homeIntent);
                        break;
                    case R.id.nav_profile:
                        // Redirect to ProfileActivity
                        Intent profileIntent = new Intent(HomeActivity.this, ProfileActivity.class);
                        profileIntent.putExtra("name", name);
                        profileIntent.putExtra("email", email);
                        profileIntent.putExtra("profile_pic", profilePicString);

                        startActivity(profileIntent);
                        break;

                    case R.id.nav_logout:
                        // Handle logout action
                        logout();
                        break;
                }
                // Close the drawer after an item is selected
                mDrawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    private void logout() {
        // Add any necessary code for logout, such as clearing user data or preferences
        // Redirect to LoginActivity or any other appropriate activity
        startActivity(new Intent(HomeActivity.this, MainActivity.class));
        finish(); // finish the current activity so that user cannot go back to it with the back button
    }
    private Bitmap decodeProfilePic(String encodedPic) {
        if (encodedPic == null) {
            return null;
        }
        byte[] decodedBytes = Base64.decode(encodedPic, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
    public void onBoxClick1(View view) {
        Intent intent = new Intent(this, Box1Activity.class);
        startActivity(intent);
    }
    public void onBoxClick2(View view) {
        Intent intent = new Intent(this, Box2Activity.class);
        startActivity(intent);
    }
    public void onBoxClick3(View view) {
        Intent intent = new Intent(this, Box3Activity.class);
        startActivity(intent);
    }
    public void onBoxClick4(View view) {
        Intent intent = new Intent(this, Box4Activity.class);
        startActivity(intent);
    }
}
