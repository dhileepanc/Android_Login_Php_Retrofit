package com.shadowws.project.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.shadowws.project.Model.User;
import com.shadowws.project.R;
import com.shadowws.project.Retrofit.ApiInstance;
import com.shadowws.project.Retrofit.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {

    private EditText mUsernameEditText;
    private EditText mEmailEditText;
    private EditText mPasswordEditText;
    private EditText mName;
    private Button mSignupButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Get references to UI elements
        mName = findViewById(R.id.nameEditText);
        mUsernameEditText = findViewById(R.id.usernameEditText);
        mEmailEditText = findViewById(R.id.emailEditText);
        mPasswordEditText = findViewById(R.id.passwordEditText);
        mSignupButton = findViewById(R.id.signupButton);

        // Change top color to white
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        // Remove title
        getSupportActionBar().hide();

        // Set click listener for signup button
        mSignupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signup();
            }
        });
    }

    private void signup() {
        // Retrieve user inputs
        String name = mName.getText().toString().trim();
        String username = mUsernameEditText.getText().toString().trim();
        String email = mEmailEditText.getText().toString().trim();
        String password = mPasswordEditText.getText().toString().trim();

        // Validate user inputs
        if (TextUtils.isEmpty(name)) {
            mName.setError("Name is required");
            mName.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(username)) {
            mUsernameEditText.setError("Username is required");
            mUsernameEditText.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(email)) {
            mEmailEditText.setError("Email is required");
            mEmailEditText.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            mEmailEditText.setError("Invalid email format");
            mEmailEditText.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            mPasswordEditText.setError("Password is required");
            mPasswordEditText.requestFocus();
            return;
        }

        if (password.length() < 6) {
            mPasswordEditText.setError("Password should be at least 6 characters long");
            mPasswordEditText.requestFocus();
            return;
        }

        // Make API call to signup user
        ApiService apiService = ApiInstance.getApiService();
        Call<User> call = apiService.signup(name, username, email, password);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful()) {
                    User user = response.body();
                    String name=user.getName();
                    Toast.makeText(SignupActivity.this, "Signup successful", Toast.LENGTH_SHORT).show();
                    // Start MainActivity
                    Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                    startActivity(intent);

                    // Close SignupActivity
                    finish();
                } else {
                    Toast.makeText(SignupActivity.this, "Signup failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Toast.makeText(SignupActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("error",t.getMessage());
            }
        });
    }

}
